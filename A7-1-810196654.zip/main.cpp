#include "Execute/Execute.h"
#include "Tools/Tools.h"
#include <iostream>

using namespace std;

int main()
{
    Execute::execute();
}