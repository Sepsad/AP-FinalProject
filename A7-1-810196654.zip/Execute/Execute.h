#ifndef _EXECUTE_H_
#define _EXECUTE_H_


class Execute
{

public:
    static void execute();
};




#endif
